<div align="center">

![Banner](./banner.svg)

</div>

---

<div align="center">

<img src="./lanyard.svg" width="200" align="right" />

## 🧠 About Me

```yaml
name        : Santhosh Shandeep  (Santho)
role        : AI Automation Expert & Full-Stack Developer
company     : Founder @ Zen4trix AI Automation  🏢
location    : Tirupur, Tamil Nadu, India  📍
languages   : Tamil | English | Code  💬
msme        : UDYAM-TN-28-0213819  ✅
currently   : Building EduZen — College Campus SaaS  🎓
open_to     : AI Projects · Automation Consulting · Collabs
```

</div>

---

## 🚀 What I Build

| Service | Description |
|--------|-------------|
| 🤖 **WhatsApp AI Bots** | Auto-replies, order tracking, 24/7 customer support |
| 🧾 **Auto Invoicing** | Instant smart billing for textile & SME businesses |
| 📅 **Appointment Systems** | WhatsApp-based smart scheduling bots |
| 🌐 **Business Websites** | Fast, modern, SEO-ready sites for local businesses |
| 🎓 **EduZen SaaS** | College campus management platform *(launching soon)* |
| 📝 **ai360tamil Blog** | Tamil-language AI education & tutorials |

---

## 🛠 Tech Stack

<div align="center">

**Frontend**

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![TailwindCSS](https://img.shields.io/badge/Tailwind-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white)

**Backend & Automation**

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)
![n8n](https://img.shields.io/badge/n8n-EA4B71?style=for-the-badge&logo=n8n&logoColor=white)
![WhatsApp API](https://img.shields.io/badge/WhatsApp%20API-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)

**AI & Deploy**

![Claude AI](https://img.shields.io/badge/Claude%20AI-FF6B35?style=for-the-badge&logo=anthropic&logoColor=white)
![OpenAI](https://img.shields.io/badge/OpenAI-412991?style=for-the-badge&logo=openai&logoColor=white)
![Netlify](https://img.shields.io/badge/Netlify-00C7B7?style=for-the-badge&logo=netlify&logoColor=white)
![Vercel](https://img.shields.io/badge/Vercel-000000?style=for-the-badge&logo=vercel&logoColor=white)

</div>

---

## 🏅 Expertise Level

<div align="center">

![WhatsApp AI Bots](https://img.shields.io/badge/💬_WhatsApp_AI_Bots-100%25-FF6B35?style=for-the-badge&labelColor=0d1117)
![AI Automation](https://img.shields.io/badge/🦾_AI_Automation-95%25-FF6B35?style=for-the-badge&labelColor=0d1117)
![n8n Workflows](https://img.shields.io/badge/⚡_n8n_Workflows-95%25-FF6B35?style=for-the-badge&labelColor=0d1117)
![Business Automation](https://img.shields.io/badge/🧾_Business_Automation-100%25-FF6B35?style=for-the-badge&labelColor=0d1117)
![Web Development](https://img.shields.io/badge/🌐_Web_Development-85%25-FF8C5A?style=for-the-badge&labelColor=0d1117)
![React & Next.js](https://img.shields.io/badge/📱_React_&_Next.js-85%25-FF8C5A?style=for-the-badge&labelColor=0d1117)
![Deploy & Hosting](https://img.shields.io/badge/☁️_Deploy_&_Hosting-90%25-FF8C5A?style=for-the-badge&labelColor=0d1117)

</div>

---

## 📊 GitHub Stats

<div align="center">

<img src="https://github-readme-stats.vercel.app/api?username=santhoshshandeep&show_icons=true&theme=dark&title_color=FF6B35&icon_color=FF6B35&text_color=ffffff&bg_color=0d1117&border_color=FF6B35&count_private=true" width="48%" />

<img src="https://github-readme-streak-stats.herokuapp.com/?user=santhoshshandeep&theme=dark&background=0d1117&ring=FF6B35&fire=FF6B35&currStreakLabel=FF6B35&border=FF6B35&sideLabels=ffffff&dates=aaaaaa" width="48%" />

</div>

---

## 🌟 Featured Projects

| Project | Description | Status |
|---------|-------------|--------|
| 🎓 [EduZen](https://github.com/santhoshshandeep) | College Campus Management SaaS | 🔨 Building |
| 🤖 [Zen4trix](https://zen4trix.in) | AI Automation Agency Website | ✅ Live |
| 📝 [ai360tamil](https://ai360tamil.blogspot.com) | Tamil AI Education Blog | ✅ Live |

---

## 🐍 Contribution Snake

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/santhoshshandeep/santhoshshandeep/output/github-contribution-grid-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/santhoshshandeep/santhoshshandeep/output/github-contribution-grid-snake.svg" />
  <img alt="github-snake" src="https://raw.githubusercontent.com/santhoshshandeep/santhoshshandeep/output/github-contribution-grid-snake.svg" />
</picture>

</div>

---

## 🎯 Current Mission

```
🎓  EduZen SaaS      →  Free pilot at Tirupur colleges → Paid SaaS
🤖  Zen4trix         →  Scaling AI bots for 50+ Tamil Nadu SMEs
📝  ai360tamil       →  Tamil AI blog — making AI accessible
```

> *"AI automation is not the future — it's the now. And I'm building it for Tamil Nadu."*

---

## 🛰 Let's Connect

<div align="center">

[![Website](https://img.shields.io/badge/🌐_Zen4trix.in-FF6B35?style=for-the-badge)](https://zen4trix.in)
[![Blog](https://img.shields.io/badge/📝_ai360tamil-0A0A0A?style=for-the-badge&logo=blogger&logoColor=FF6B35)](https://ai360tamil.blogspot.com)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/santhoshshandeep)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/zen4trix)
[![Email](https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:hello@zen4trix.in)

</div>

---

<div align="center">

**⭐ Star my repos if you find them useful!**

![Footer](https://capsule-render.vercel.app/api?type=waving&color=FF6B35&height=100&section=footer)

</div>
